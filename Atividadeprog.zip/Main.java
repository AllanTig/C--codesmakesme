import java.util.Scanner;
class Main {
 public static void main(String[] args) {
   Scanner entrada = new Scanner(System.in);
 
   int ESC;
   String N;
 
   System.out.print("Informe o nome do vendedor:");
   N = entrada.nextLine();
 
 
   try {
    Thread.sleep (2000);
    } catch (InterruptedException ex) {}
 
   System.out.print("\n1 - Solteiro(a)\n2 - Desquitado(a)\n3 - Casado(a)\n4 - Viúvo");
 
   System.out.print("\nEm qual estdo civil voce se encontra (codigo):");
   ESC = entrada.nextInt();
   try {
    Thread.sleep (2000);
    } catch (InterruptedException ex) {}
 
   switch (ESC){
 
     case 1:{
       System.out.println("\nNome do vendedor:\t"+N);
       System.out.print("\nEstado civil: 1 - Solteiro(a)");
     }break;
 
     case 2:{
       System.out.println("\nNome do vendedor:\t"+N);
       System.out.print("\nEstado civil: 2 - Desquitado(a)");
     }break;
 
     case 3:{
       System.out.println("\nNome do vendedor:\t"+N);
       System.out.print("\nEstado civil: 3 - Casado(a)");
     }break;
 
     case 4:{
       System.out.println("\nNome do vendedor:\t"+N);
       System.out.print("\nEstado civil: 4 - Viúvo");
     }break;
 
     default:{
       System.out.print("\nERRO!!! Codigo nao encontrado");
     }break;
 
 
   }
  
  }
}