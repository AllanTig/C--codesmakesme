#include <stdio.h>
/*int aeiou(char palavra[40]){
  int contador=0,contadorp=0;
  
  for(contador=0;contador<=40;contador++){

if(palavra[contador]=='a'){
  contadorp++;
}
else if(palavra[contador]=='e'){
  contadorp++;
}
else if(palavra[contador]=='i'){
  contadorp++;
}
else if(palavra[contador]=='o'){
  contadorp++;
}
else if(palavra[contador]=='u'){
  contadorp++;
}
  }
return contadorp;
  }
  
int main() {
  int vogais;
  char palavra[40];
printf("informe uma palavra: ");
scanf("%s",palavra);
vogais=aeiou(palavra);
printf("a quantidade de vogais existentes na palavra sao: %d",vogais);
}*/
/*int consoantes(char palavra[40]){
  int contador=0,contadorp=0;
  
  for(contador=0;contador<=40;contador++){

if(palavra[contador]=='b'){
  contadorp++;
}
else if(palavra[contador]=='c'){
  contadorp++;
}
else if(palavra[contador]=='d'){
  contadorp++;
}
else if(palavra[contador]=='f'){
  contadorp++;
}
else if(palavra[contador]=='g'){
  contadorp++;
}
else if(palavra[contador]=='h'){
  contadorp++;
}
else if(palavra[contador]=='j'){
  contadorp++;
}
else if(palavra[contador]=='k'){
  contadorp++;
}
else if(palavra[contador]=='l'){
  contadorp++;
}
else if(palavra[contador]=='m'){
  contadorp++;
}
else if(palavra[contador]=='n'){
  contadorp++;
}
else if(palavra[contador]=='p'){
  contadorp++;
}
else if(palavra[contador]=='q'){
  contadorp++;
}
else if(palavra[contador]=='r'){
  contadorp++;
}
else if(palavra[contador]=='s'){
  contadorp++;
}
else if(palavra[contador]=='t'){
  contadorp++;
}
else if(palavra[contador]=='v'){
  contadorp++;
}
else if(palavra[contador]=='w'){
  contadorp++;
}
else if(palavra[contador]=='x'){
  contadorp++;
}
else if(palavra[contador]=='y'){
  contadorp++;
}
else if(palavra[contador]=='z'){
  contadorp++;
}
  }
return contadorp;
  }
  
int main() {
  int consoante;
  char palavra[40];
printf("informe uma palavra: ");
scanf("%s",palavra);
consoante=consoantes(palavra);
printf("a quantidade de consoantes existentes na palavra sao: %d",consoante);
}*/
int 

printf (" ")