
using System;
 /*
 class MainClass {

 static void Main(string[] args)

  {    double x, y, c;            
  Console.WriteLine("informe o valor do litro do combustivel");
 x = double.Parse (Console.ReadLine());

 Console.WriteLine("informe o valor que ele deseja abastecer");
 y= double.Parse (Console.ReadLine());
 c= y/x; 
 Console.Write("O valor e: " + c);
 Console.ReadKey();
  }
  }
 */
 /*
 class MainClass {

 static void Main(string[] args)

  {    double x, y, c;            
  Console.WriteLine("informe o salario mensal do usuario");
 x = double.Parse (Console.ReadLine());

 Console.WriteLine("informe o valor das despesas mensais");
 y= double.Parse (Console.ReadLine());
 c=x-y; 
 for ()
 
 Console.Write("O valor e: " + c);
 Console.ReadKey();
  }
  }

 */

 /*
 class MainClass {

 static void Main(string[] args)

  { double  tempanos, salario, gasto, restante, contador=0;            
  Console.WriteLine("informe o salário mensal");
  double salario = double.Parse(Console.ReadLine());

  Console.WriteLine("informe o total de despesas mensais");
  double gasto = double.Parse(Console.ReadLine());
  restante=salario-gasto;
  for (i=restante;i<=1000000;i+=restante){
  contador++;
  }
  tempanos=contador/12;
  Console.Write("o tempo em anos e: "+tempanos);
  Console.ReadKey(); 
  }
  }*/

 /*
 class MainClass {

 static void Main(string[] args)

 { char escolha[10];
 Console.WriteLine("informe uma regiao do brasil");

