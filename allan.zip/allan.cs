 using System;
/*
class MainClass {
  public static void Main (string[] args) {
    double salario, percentual;

    Console.WriteLine ("informe o valor do seu salario atual:");
    salario= double.Parse(Console.ReadLine());
    Console.WriteLine ("informe o percentual de aumento:");
    percentual= double.Parse(Console.ReadLine());
    percentual=percentual/100;
    salario=salario*(percentual+1);
    Console.Write ("salario atual "+salario);
  }
}*/
class MainClass {
  public static void Main (string[] args) {
    char [] salario= new int[2];

    Console.WriteLine ("informe o valor do seu salario atual:");
    escolha= char.Parse(Console.ReadLine());
    switch (escolha){
      case 'SC':
      Console.WriteLine ("cachorro quente + refrigerante");
      break;
      case 101:
      Console.WriteLine ("misto quente + refrigerante");
      break;
      case 102:
      Console.WriteLine ("misti frio + refrigerante");
      break;
      case 103:
      Console.WriteLine ("queijo quente + refrigerante");
      break;
      default:
      Console.WriteLine ("nao listado");
      break;
    }
  }
