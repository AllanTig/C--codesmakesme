import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    Scanner entrada = new Scanner(System.in);
    aritimetica aritimetica = new aritimetica ();
    ponderada ponderada = new ponderada ();

    double pesos=0, soma = 0, somas = 0, equacao = 0, valores = 0, valor = 0, peso = 0;
    char desejo;
  do {
    System.out.println("Média Aritimética = a ou A");
    System.out.println("Média Ponderada = p ou P");
    char escolha = entrada.next().charAt(0);


    if ('A' == escolha || 'a' == escolha){

      System.out.println("Quantos valores deseja atribuir?");
      int contagem = entrada.nextInt();

      for(int i=1; i <= contagem ;i++){

        System.out.println("Valor"+i+":");
        valores = entrada.nextDouble();

        soma+=valores;

      }

     equacao = aritimetica.equacao (soma, contagem);


    }

    else if ('P' == escolha || 'p' == escolha){

      System.out.println("Quantos valores deseja atribuir?");
      int contagem = entrada.nextInt();

      for(int i=1; i <= contagem ;i++){

        System.out.println("Valor"+i+":");
        valor = entrada.nextDouble();
        System.out.println("Peso"+i+":");
        peso = entrada.nextDouble();

        pesos+=peso;
        somas = peso*valor;
        soma+=somas;

      }

      equacao = ponderada.equacao (soma, contagem, pesos);

    }

    System.out.println("nota final:"+ equacao);

    pesos=0; 
    soma = 0; 
    somas = 0; 
    equacao = 0; 
    valores = 0; 
    valor = 0; 
    peso = 0;

    System.out.println("Digite s ou S paa continuar");
    desejo = entrada.next().charAt(0);

  }  while ((desejo == 's') || (desejo == 'S'));
  }
}