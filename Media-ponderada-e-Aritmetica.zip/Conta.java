class aritimetica{

    public double equacao (double soma, int contagem){
      double conta;
      conta = soma/contagem;
      return conta;
    }
  }


class ponderada{

    public double equacao (double soma, int contagem, double pesos){
      double conta;
      conta = soma/pesos;
      return conta;
    }
  }